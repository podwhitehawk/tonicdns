<?php
/**
 * Copyright (c) 2011 Cyso Managed Hosting < development [at] cyso . nl >
 *
 * This file is part of TonicDNS.
 *
 * TonicDNS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * TonicDNS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with TonicDNS.  If not, see <http://www.gnu.org/licenses/>.
 */
/**
 * Interface for a Token backend.
 * @namespace Tonic\Lib
 */
interface TokenBackend {
	/**
	 * Should create a new Token, store it in the backend and return it.
	 * @access public
	 * @param mixed $token Token object with the username and password properties set.
	 * @return mixed Token object.
	 */
	public function createToken($token);

	/**
	 * Should retrieve a Token based on the passed ID.
	 * @access public
	 * @param string $token_id Token ID
	 * @return mixed Token object, or null if it could not be retrieved.
	 */
	public function retrieveToken($token_id);

	/**
	 * Should refresh the duration of the passed Token. If the Token is expired, it should be destroyed.
	 * @access public
	 * @param mixed $token_id Token ID.
	 * @return boolean True if successful, false if the Token could not be refreshed.
	 */
	public function refreshToken($token_id);

	/**
	 * Validate the passed Token object, and determine if it is still valid. Any invalid Token 
	 * found in the backend should be cleaned up by this function.
	 * @access public
	 * @param mixed $token Token object.
	 * @return boolean True if Token is still valid, false if it is not.
	 */
	public function validateToken($token);

	/**
	 * Destroy the given Token object, by invalidating and removing it from the backend.
	 * @access public
	 * @param mixed $token Token object.
	 * @return boolean True if succesful, false if the Token could not be destroyed.
	 */
	public function destroyToken($token);
}

/**
 * Defines the Token object for use with a Token backend.
 * @namespace Tonic\Lib
 */
class Token {
	/**
	 * Username for this Token. Used during createToken.
	 * @access public
	 * @var string
	 */
	public $username;
	/**
	 * Password for this Token. Used during createToken.
	 * @access public
	 * @var string
	 */
	public $password;
	/**
	 * Validity of this Token. If this date lies in the past, the Token is invalid. Used during refreshToken and validateToken.
	 * @access public
	 * @var date
	 */
	public $valid_until;
	/**
	 * Hashed version of the above information. Used during createToken, retrieveToken, refreshToken, validateToken and destroyToken.
	 * @access public
	 * @var string
	 */
	public $hash;

	/**
	 * Convenience constructor to completely fill a Token object during construction.
	 * @access public
	 */
	public function __construct($username = null, $password = null, $valid_until = null, $hash = null) {
		$this->username = $username;
		$this->password = $password;
		$this->valid_until = $valid_until;
		$this->hash = $hash;
	}

	/**
	 * Returns an array representation of the Token object.
	 * @access public
	 * @return array Array representation of the Token object.
	 */
	public function toArray() {
		return array (
			"username" => $this->username,
			"valid_until" => $this->valid_until,
			"hash" => $this->hash,
			"token" => $this->hash
		);
	}
}

?>
