#!/bin/sh
cd ../conf;
cp validator.conf.php.default validator.conf.php
cp logging.conf.php.default logging.conf.php
