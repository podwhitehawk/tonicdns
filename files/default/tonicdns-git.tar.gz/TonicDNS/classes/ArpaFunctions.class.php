<?php
/**
 * Copyright (c) 2011 Cyso Managed Hosting < development [at] cyso . nl >
 *
 * This file is part of TonicDNS.
 *
 * TonicDNS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * TonicDNS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with TonicDNS.  If not, see <http://www.gnu.org/licenses/>.
 */
/**
 * Arpa support functions
 */
class ArpaFunctions {
	public function get_all_arpa($response, &$out = null, $query = null) {
		$zones = array();
		$filter_ranges = array();
		if (empty($query)) {
			ZoneFunctions::query_zones($response, "*.in-addr.arpa", $temp);
			if (!empty($temp)) {
				foreach ($temp as $t) {
					$zones[] = $t['name'];
				}
			}
			ZoneFunctions::query_zones($response, "*.ip6.arpa", $temp);
			if (!empty($temp)) {
				foreach ($temp as $t) {
					$zones[] = $t['name'];
				}
			}
		} else {
			$q = explode(",", $query);
			$singles = array();
			$singles6 = array();
			$ranges = array();

			foreach ($q as $s) {
				if (preg_match(VALID_IPV4_RANGE, $s)) {
					$range = HelperFunctions::calc_ipv4_range($s);

					if (!empty($singles)) {
						for ($i = count($singles) - 1; $i >= 0; $i--) {
							if (HelperFunctions::is_ipv4_in_range($range, $singles[$i])) {
								unset($singles[$i]);
							}
						}
					}
					$ranges[] = $range;
					continue;
				}
				if (preg_match(VALID_IPV4, $s)) {
					if (!empty($ranges)) {
						$in_range = false;
						foreach ($ranges as $range) {
							if (HelperFunctions::is_ipv4_in_range($range, $s)) {
								$in_range = true;
								break;
							}
						}
						if (!$in_range) {
							$singles[] = $s;
						}
					} else {
						$singles[] = $s;
					}
					continue;
				}
				if (preg_match(VALID_IPV6_RANGE, $s)) {
					$r = explode("/", $s, 2);
					$s = $r[0];
				}
				if (preg_match(VALID_IPV6, $s)) {
					if (!in_array($s, $singles6)) {
						$singles6[] = $s;
					}
					continue;
				}
			}

			$output = array();
			$filter_singles = $singles;

			foreach ($ranges as $range) {
				$singles = array_merge($singles, HelperFunctions::expand_ipv4_range($range));
			}
			$singles = array_merge($singles, $singles6);

			foreach ($singles as $single) {
				$arpa = HelperFunctions::ip_to_arpa($single);
				$found = null;
				for ($i = 0; ($ret = HelperFunctions::truncate_arpa($arpa, $i)) !== false; $i++) {
					if (in_array($ret, $zones) !== false) {
						$found = true;
						break;
					}
					$res = ZoneFunctions::get_zone($response, $ret, $out, false, false);

					if ($res->code !== Response::NOTFOUND) {
						$found = $ret;
						break;
					}
				}

				if ($found === true) {
					continue;
				} elseif ($found) {
					$zones[] = $found;
				} else {
					$output[] = array(
						"name" => $arpa,
						"ip" => $single,
						"reverse_dns" => null,
						"arpa_zone" => null
					);

					$index = array_search($single, $filter_singles);
					if ($index !== false) {
						unset($filter_singles[$index]);
					}
				}
			}
			$filter_ranges = $ranges;
		}

		foreach ($zones as $zone) {
			$records = null;
			ZoneFunctions::get_zone($response, $zone, $records);
			if (empty($records)) {
				continue;
			}
			foreach ($records['records'] as $record) {
				if ($record['type'] == "PTR") {
					$ip = HelperFunctions::arpa_to_ip($record['name']);
					$allowed = false;
					if (!empty($filter_ranges) && strpos(":", $ip) === false) {
						foreach ($filter_ranges as $filter) {
							if (HelperFunctions::is_ipv4_in_range($filter, $ip)) {
								$allowed = true;
								break;
							}
						}
					}
					if (!$allowed && !empty($filter_singles) && in_array($ip, $filter_singles)) {
						$allowed = true;
						$index = array_search($ip, $filter_singles);
						unset($filter_singles[$index]);
					}
					if (!$allowed) {
						continue;
					}
					$output[] = array(
						"name" => $record['name'],
						"ip" => HelperFunctions::arpa_to_ip($record['name']),
						"reverse_dns" => $record['content'],
						"arpa_zone" => $zone
					);
				}
			}
		}

		foreach ($filter_singles as $missing) {
			if (preg_match(VALID_IPV4, $missing)) {
				foreach ($zones as $zone) {
					if (HelperFunctions::is_ipv4_in_range(HelperFunctions::calc_ipv4_range(HelperFunctions::arpa_to_ipv4_cidr($zone)), $missing)) {
						$output[] = array(
							"name" => HelperFunctions::ip_to_arpa($missing),
							"ip" => $missing,
							"reverse_dns" => null,
							"arpa_zone" => $zone
						);
					}
				}
			}
		}

		if (empty($output)) {
			$response->code = Response::NOTFOUND;
			$response->error = "Could not find any records for given query.";
			$response->error_detail = "ARPA_NO_RECORDS";
			$out = false;
		} else {
			$response->code = Response::OK;
			$response->body = $output;
			$response->log_message = sprintf("Query returned %d Arpa records", count($output));
			$out = $output;
		}
		return $response;
	}

	public function query_arpa($response, $query, &$out = null) {
		return ArpaFunctions::get_all_arpa($response, $out, $query);
	}

	public function get_arpa($response, $identifier, &$out = null, $extra_props = false) {
		$arpa = HelperFunctions::ip_to_arpa($identifier);

		for ($i = 0; ($ret = HelperFunctions::truncate_arpa($arpa, $i)) !== false; $i++) {
			$response = ZoneFunctions::get_zone($response, $ret, $out);

			if ($response->code !== Response::NOTFOUND) {
				foreach ($out['records'] as $record) {
					if ($record['type'] == "PTR" && 
						HelperFunctions::ipv6_expand($identifier) == HelperFunctions::arpa_to_ip($record['name'])) {
							$output = array(
								"name" => $record['name'],
								"ip" => $identifier,
								"reverse_dns" => $record['content'],
								"arpa_zone" => $ret
							);

							if ($extra_props) {
								$output['ttl'] = $record['ttl'];
								$output['priority'] = $record['priority'];
							}

							$response->code = Response::OK;
							$response->body = $output;
							$response->log_message = sprintf("Retrieved Arpa zone '%s' for IP '%s'", $record['name'], $identifier);
							$out = $output;
							return $response;
					}
				}
			}
		}

		$response->code = Response::NOTFOUND;
		$response->error = "Could not find the Arpa zone for IP " . $identifier;
		$response->error_detail = "ARPA_NO_ZONE_FOR_IP";
		$out = false;
		return $response;
	}

	public function create_arpa($response, $identifier, $data, &$out = null) {
		ArpaFunctions::get_arpa($response, $identifier, $o);

		if (!empty($o)) {
			$response->code = Response::CONFLICT;
			$response->error = "Resource already exists";
			$response->error_detail = "ARPA_ALREADY_EXISTS";
			$out = false;
			return $response;
		}
		$response->error = null;

		unset($o);

		ZoneFunctions::get_zone($response, $identifier, $o, false);

		if (empty($o)) {
			if ($response->code == Response::NOTFOUND) {
				$response->error = sprintf("Could not find Arpa zone for ip '%s'", $identifier);
				$response->error_detail = "ARPA_ZONE_NOT_FOUND";
			}
			$out = false;
			return $response;
		}

		$zone = $o['name'];

		unset($o);

		$record = new stdClass();
		$record->name = HelperFunctions::ip_to_arpa($identifier);
		$record->type = "PTR";
		$record->content = $data;

		$req = new stdClass();
		$req->records = array($record);

		$response = ZoneFunctions::create_records($response, $zone, $req, $o, true);

		if (empty($o)) {
			return $response;
		}

		$response->code = Response::OK;
		$response->body = true;
		$response->log_message = sprintf("Added '%s' to Arpa zone '%s'", $identifier, $zone);

		$out = true;

		return $response;
	}

	public function delete_arpa($response, $identifier, &$out = null) {
		ArpaFunctions::get_arpa($response, $identifier, $o, true);

		if (empty($o)) {
			$out = false;
			return $response;
		}

		$record = new stdClass();
		$record->name = $o['name'];
		$record->type = "PTR";
		$record->content = $o['reverse_dns'];
		$record->priority = $o['priority'];

		$req = new stdClass();
		$req->records = array($record);


		$response = ZoneFunctions::delete_records($response, $o['arpa_zone'], $req, $o);

		if (empty($o)) {
			$out = false;
			return $response;
		}

		$response->code = Response::OK;
		$response->body = true;
		$response->log_message = sprintf("Deleted Arpa record for IP %s", $identifier);

		$out = true;

		return $response;
	}
}
?>
